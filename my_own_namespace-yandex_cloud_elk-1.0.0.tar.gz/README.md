# Ansible Collection - my_own_namespace.yandex_cloud_elk

Documentation for the collection.
В данной коллекции содержится роль my_module, которая производит вызов модуля my_own_module.
Модуль my_own_module производит создание файла по пути path с содержимым content.
Если по указаному пути path файл уже существует, то модель заканчивает работу пропуская шаг создания файла и его наполнения.
